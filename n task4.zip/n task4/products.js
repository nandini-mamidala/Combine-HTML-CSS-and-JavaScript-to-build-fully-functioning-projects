const products = [
  { name: "Product A", price: 30, rating: 4.5 },
  { name: "Product B", price: 70, rating: 3.8 },
  { name: "Product C", price: 120, rating: 4.9 },
  { name: "Product D", price: 45, rating: 4.2 },
  { name: "Product E", price: 80, rating: 3.5 }
];

function renderProducts(filtered) {
  const productList = document.getElementById("productList");
  productList.innerHTML = "";
  filtered.forEach(p => {
    const div = document.createElement("div");
    div.className = "product-card";
    div.innerHTML = `<h3>${p.name}</h3><p>Price: $${p.price}</p><p>Rating: ⭐ ${p.rating}</p>`;
    productList.appendChild(div);
  });
}

function filterProducts() {
  let filtered = [...products];
  const priceFilter = document.getElementById("priceFilter").value;
  const sortRating = document.getElementById("sortRating").value;

  if (priceFilter === "low") filtered = filtered.filter(p => p.price < 50);
  if (priceFilter === "high") filtered = filtered.filter(p => p.price >= 50);

  if (sortRating === "high") filtered.sort((a, b) => b.rating - a.rating);
  if (sortRating === "low") filtered.sort((a, b) => a.rating - b.rating);

  renderProducts(filtered);
}

filterProducts();
